clc,clear
filename ='House.tif';

for j  = 2   

randn ('seed',0);

Sigma_Num            = [10,20,30,40,50,75,100];
      
Sigma            =      Sigma_Num (j);
     
% Sigma=enoise2(imread('city.tif'))
  
 [filename, Sigma, PSNR_Final,SSIM_Final,im,zzz,I,Ino,error ]     =  SRRC_Test (filename, Sigma); 

end

plot(nonzeros(error),'b','LineWidth',2)
xlabel('Number of iterations');
ylabel('Error value');
% imshow(im,[])


% h=[110,150];
% v=[210,250];
% hsize=h(2)-h(1);
% vsize=v(2)-v(1);
% hvsize=[hsize,vsize];
% % 
% % I = mm(I,h,v);
% % I = drawRectangleFrame(I,[h(2),v(2)],hvsize);
% % 
% % Ino = mm(Ino,h,v);
% % Ino = drawRectangleFrame(Ino,[h(2),v(2)],hvsize);
% % 
% im = mm(im,h,v);
% im = drawRectangleFrame(im,[h(2),v(2)],hvsize);
% toc
% imshow(im,[])
% 
% imshow(I,[])
% title('ԭʼͼ��')
% 
% figure
% imshow(im,[])
% title('��ԭͼ��')
         