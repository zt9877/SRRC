clc,clear
close all
x=1:1:17;
y=[21.53,24.17,26.72,27.89,28.36,28.59,28.70,28.76,28.79,28.81,28.81,28.81,28.80,28.80,28.79,28.79,28.78
    21.89,25.25,28.70,29.76,30.11,30.27,30.36,30.42,30.47,30.50,30.52,30.54,30.56,30.57,30.58,30.59,30.60
    22.05,25.78,30.23,31.73,32.27,32.56,32.76,32.91,33.02,33.11,33.17,33.22,33.26,33.29,33.31,33.31,33.30];
plot(x,y(1,:),'r','LineWidth',2)
hold on
plot(x,y(2,:),'g','LineWidth',2)
hold on
plot(x,y(3,:),'b','LineWidth',2)
xlabel('Number of iterations');
ylabel('PSNR value');
legend('Monarch','Parrots','Foreman')
frame = getframe(fig); % ��ȡframe
img = frame2im(frame); % ��frame�任��imwrite��������ʶ��ĸ�ʽ
imwrite(img,'1.png')