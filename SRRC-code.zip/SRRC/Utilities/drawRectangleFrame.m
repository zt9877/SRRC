function [drawRectangleImage] = drawRectangleFrame(image,windowLocation,windowSize)
[row,col] = size(image); 
x = windowLocation(1);
y = windowLocation(2);
height = windowSize(1);%���ο�ߴ磬���ʽΪ[height,width]����[�߶�,����]
width = windowSize(2);
if((x<=row && y<=col)&&(height<=row && width<=col))
    disp('���ο�Ϸ���');
   
    figure();
    imshow(image,[]);
    
    hold on
    drawRectangleImage = rectangle('Position',[y-width,x-height,width,height],'LineWidth',2,'EdgeColor','r','LineStyle','--');
    
    drawRectangleImage2 = rectangle('Position',[0,col-2*height,2*width,2*height],'LineWidth',2,'EdgeColor','b','LineStyle','--');
   
    hold off
    
else
    disp('���ο򲻺Ϸ���');
end
end