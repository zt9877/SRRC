function [filename, Sigma, PSNR_Final,SSIM_Final,im,zzz,I,Ino,error]     =  SRRC_Test (filename, Sigma)

randn ('seed',0);

I                =     imread(filename);

[~, ~, kk]       =     size (I);

if kk==3
    
    I     = rgb2gray (I);
       
end


Opts              =    Opts_Set (Sigma, I); % parameter setting

Opts.nim          =    Opts.I + Opts.nSig* randn(size( Opts.I ));


Ino=Opts.nim ;

disp(sprintf('PSNR of the noisy image = %f \n', csnr(Opts.nim, Opts.I, 0, 0) ));


[Denoising , iter,zzz,error]              =    SRRC_Denoising( Opts);

im  = Denoising{iter-1};


PSNR_Final       =   csnr (im, Opts.I,0,0);

SSIM_Final       =   cal_ssim (im, Opts.I,0,0);






end

