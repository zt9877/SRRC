function X = mm(X,h,v)
i =X(h(1):(h(2)-1),v(1):(v(2)-1));
i1=imresize(i,2);
[m,n]=size(i1);
X(end-m+1:end,1:n)=i1;
end