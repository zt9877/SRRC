function Sigma=enoise2(X)
% X=imread('book.tif');

[~, ~, kk]       =     size (X);

if kk==3
    
   X=rgb2gray(X);
       
end
X=double(X);
r=rank(X);M=0.75*r;PM=0;
[u1,s1,v1]=svd(X);
for i=(r-round(M)+1):1:r
    s11=s1(i,i);
    PM=PM+s11;  
end
Sigma=PM/(10*M)


end