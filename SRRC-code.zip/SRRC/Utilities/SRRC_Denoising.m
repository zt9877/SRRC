
function  [Denoising , iter,zzz,error]     =     SRRC_Denoising( Opts)

randn ('seed',0);

Nim            =   Opts.nim;

b              =   Opts.win;

[h, w, ch]     =   size(Nim);

N              =   h-b+1;

M              =   w-b+1;

r              =   [1:N];

c              =   [1:M]; 

Out_Put        =   Nim;

gamma          =   Opts.gamma;

nsig           =   Opts.nSig;

m              =   Opts.nblk;

cnt            =   1;

Denoising      =  cell (1,Opts.Iter);

error=zeros(1,Opts.Iter);

for iter = 1 :Opts.Iter    
    
        Out_Put               =    Out_Put + gamma*(Nim - Out_Put);
        
         dif                  =    Out_Put-Nim;
        
         vd                   =    nsig^2-(mean(mean(dif.^2)));
     
   [blk_arr, wei_arr]         =    Block_matching( Out_Put, Opts);          
        
    if iter==1
        
                      
            Opts.nSig         =    sqrt(abs(vd)); 
    else
        
            Opts.nSig         =    sqrt(abs(vd))*Opts.lamada;          
   end 
        
     
               X             =     Im2Patch( Out_Put, Opts );  
               
               Ys            =     zeros( size(X) );   
               
               W             =     zeros( size(X) );
               
               K             =     size(blk_arr,2);
               
               NL_A          =     zeros (b*b, Opts.nblk);
               
         zzz=cell(1,K);     
         zz2=cell(1,K);        
        for  i  =  1 : K  
            %
            % Get Nonlocal Similar patches from noisy image...
            
               A             =      X(:, blk_arr(:, i));    
               
            Weight           =      repmat(wei_arr(:, i)',size(A, 1), 1);       
               
          for j = 1:m
              
               % recursive algorithm
              wei            =      Weight(:,1:m-j+1);
              
              a              =      A(:,1:m-j+1);

             nla_app         =      sum(wei.*a, 2); % NLM_Means    % Eq.(6)  
                         
             NL_A (:, j)     =      nla_app;
             
          end
               
            
            [TMP,z,z2]              =    SRRC_CORE( double(A), double(NL_A), Opts.c1, Opts.nSig, Opts.eps );
             zzz{i}=z;
             zz2{i}=z2;
    
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%          
    Ys(:, blk_arr(1:m,i))    =   Ys(:, blk_arr(1:m,i)) + TMP;
    
    W(:, blk_arr(1:m,i))     =   W(:, blk_arr(1:m,i)) + 1;
    
        end

     Out_Put        =   zeros(h,w);       
     
     im_wei        =  zeros(h,w);     
     
      k            =   0;
      
     for i   =  1:b
         for j  = 1:b
                k    =  k+1;
                Out_Put(r-1+i,c-1+j)  =  Out_Put(r-1+i,c-1+j) + reshape( Ys(k,:)', [N M]);
                im_wei(r-1+i,c-1+j)  =  im_wei(r-1+i,c-1+j) + reshape( W(k,:)', [N M]);
          end
     end
     
      Out_Put            =        Out_Put./(im_wei+eps);
        
     Denoising{iter}    =        Out_Put;
     
     error(1,iter)=log(norm(Nim - Out_Put,'fro').^2/norm(Nim,'fro').^2);

              
    fprintf( 'Iteration %d : nSig = %2.2f, PSNR = %2.2f\n', cnt, Opts.nSig, csnr( Out_Put, Opts.I, 0, 0 ));
    fprintf( 'SSIM = %2.4f, Objective function value=%2.2f\n', vpa(cal_ssim (Out_Put, Opts.I,0,0),4),sum(sum(z2)));
    cnt   =  cnt + 1;
        
  
       if  iter >1
      
            dif      =  norm(abs(Denoising{iter}) - abs(Denoising{iter-1}),'fro')/norm(abs(Denoising{iter-1}), 'fro');
       
         if dif<Opts.error
           
               break;
         end
       
      end
  
   
end


end





