function Sigma=enoise(X)
% X=imread('book.tif');

[~, ~, kk]       =     size (X);

if kk==3
    
   X=rgb2gray(X);
       
end
X=double(X);

% X=double(imread('House.tif'));
% ss=10;
% X        =    X + ss* randn(size(X));
r=rank(X);M=0.75*r;
a=13.87;%256:9.83;512:13.87
ss=50;
nim        =    X + ss* randn(size(X));
[u1,s1,v1]=svd(X);[u2,s2,v2]=svd(nim);
PM=0;PM1=0;
for i=(r-round(M)+1):1:r
    s11=s1(i,i);
    s12=s2(i,i);
    PM=PM+s11;  
    PM1=PM1+s12;
end
PM=PM/M;PM1=PM1/M;
S1=(a*ss^2)/(2*PM1-2*PM);
S2=(PM1-PM)/(2*a);
Sigma=S1-S2;
end