

function  [X,z,z2]  =   SRRC_CORE( A, B, c1, nSig,ee )

[S, A0, D]            =                svd(double(full(A)),'econ');  %svd(CurArray);

[m, ~]                =                size (A0);

[~, B0, ~]            =                svd(double(full(B)),'econ');  %svd(CurArray);
 
 s0                   =                A0 -   B0;

 s0                   =                mean (s0.^2,2);
 
 s0                   =                max  (0, s0-nSig^2);

 z=A0-B0;

z1 =length(find(z<10^-6));
z2 =prod(size(z));
p=z1/z2;
% p=0.9;

 lam                  =                repmat(((c1*sqrt(3)*nSig^(2/p))./(sqrt(s0) + ee)),[1,m]); 

Alpha  = GST(A0-B0,lam,p,1)+B0;

X                     =                S*Alpha*D';

z2=1/2*(A0-Alpha).^2+lam.*(Alpha-B0)^p;
return;