function y = GST(x,w,p,J)

ttGST=(2.*w.*(1-p)).^(1/(2-p))+w.*p.*(2.*w.*(1-p)).^((p-1)./(2-p));
tsig=max(abs(x)-ttGST,0);

k=0;sigma=abs(x);
for k=0:1:J
    sigma=abs(x)-w.*p.*(sigma.^(p-1));
    k=k+1;
end
y=sign(x).*sigma.*sign(tsig);

% y=sign(x).*max(sigma,0);
end

